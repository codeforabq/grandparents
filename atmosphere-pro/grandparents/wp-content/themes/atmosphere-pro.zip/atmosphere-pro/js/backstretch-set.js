/**
 * This script sets the Backstretch arguments in the Atmosphere Pro Theme.
 *
 * @package Atmosphere\JS
 * @author StudioPress
 * @license GPL-2.0+
 */

jQuery(document).ready(function($) {

	$(".front-page-1").backstretch([BackStretchImg.src]);

});